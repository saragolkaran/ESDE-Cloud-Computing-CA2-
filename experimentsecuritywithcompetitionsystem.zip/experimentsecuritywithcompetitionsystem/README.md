# Node.js® Vulneraby Rest API Web Application using (Express.js | MySQL )

This is a sample web application which has vulnerable REST API endpoints.

# Requirements (Ensure your laptop has installed NodeJs and Gulp)

- NodeJS
- Gulp

# Installation Steps

1- Download and unzip this repo.

2- View the two setup videos in blackboard to setup the project.

3- The project already contains the node_modules
  
4- Start the application. (After you have followed the two videos)
```
node index.js
```

# Usage

By default application uses 5000 port. You can access app via http://localhost:5000

